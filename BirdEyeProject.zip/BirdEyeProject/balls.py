from networktables import NetworkTables
import sys
import time
import cv2
import logging
import numpy as np
logging.basicConfig(level=logging.DEBUG)
roboRIO_ip = '10.8.46.2'
NetworkTables.initialize(server=roboRIO_ip)
sd = NetworkTables.getTable("SmartDashboard")
#with open("variables.txt") as f:
#    content = f.read()
x = open("variables.txt").read()
print(x)
i = 0
s_img = cv2.imread("a.png")

while True:
    number = int(sd.getNumber(str(x), 0))
    ballSize = s_img.shape[1]
    l_img = np.zeros((ballSize, ballSize*number, 3), np.uint8)
    for i in range(0, number):
        x_offset=(ballSize*i)
        y_offset=0
        l_img[y_offset:y_offset+s_img.shape[0], x_offset:x_offset+s_img.shape[1]] = s_img
    print(str(x), int(sd.getNumber(str(x), 0)))
    #cv2.imshow('image', l_img)
    #cv2.waitKey(1000000)
